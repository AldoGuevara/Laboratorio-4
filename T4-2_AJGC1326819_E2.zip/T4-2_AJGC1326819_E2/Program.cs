﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T2_AJGC1326819_E2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            
            Console.WriteLine("Nombre: Aldo Guevara ");
            Console.WriteLine("Número de Carné: 1326819");

            
            Console.Write("Ingrese una cantidad en quetzales (entre 0 y 999.99): ");
            double cantidadEnQuetzales = Convert.ToDouble(Console.ReadLine());

            if (cantidadEnQuetzales >= 0 && cantidadEnQuetzales <= 999.99)
            {
                
                int cantidadEnCentavos = (int)(cantidadEnQuetzales * 100);

                
                int billetes100 = cantidadEnCentavos / 10000;
                cantidadEnCentavos %= 10000;

                int billetes50 = cantidadEnCentavos / 5000;
                cantidadEnCentavos %= 5000;

                int billetes20 = cantidadEnCentavos / 2000;
                cantidadEnCentavos %= 2000;

                int billetes10 = cantidadEnCentavos / 1000;
                cantidadEnCentavos %= 1000;

                int billetes5 = cantidadEnCentavos / 500;
                cantidadEnCentavos %= 500;

                int monedas1 = cantidadEnCentavos / 100;
                cantidadEnCentavos %= 100;

                int monedas25Centavos = cantidadEnCentavos / 25;
                cantidadEnCentavos %= 25;

                int monedas1Centavo = cantidadEnCentavos;

         
                Console.WriteLine($"{billetes100} de Q 100");
                Console.WriteLine($"{billetes50} de Q 50");
                Console.WriteLine($"{billetes20} de Q 20");
                Console.WriteLine($"{billetes10} de Q 10");
                Console.WriteLine($"{billetes5} de Q 5");
                Console.WriteLine($"{monedas1} de Q 1");
                Console.WriteLine($"{monedas25Centavos} de 25 centavos");
                Console.WriteLine($"{monedas1Centavo} de 1 centavo");
            }
            else
            {
                Console.WriteLine("Error: La cantidad ingresada debe estar entre 0 y 999.99 quetzales.");

                Console.ReadKey();


            }

            }//CIERRE 3 
    }// CIERRE 2 
}//CIERRE 1
