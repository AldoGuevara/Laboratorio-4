﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L4_AJGC1326819
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1: Operaciones aritméticas");

            
            Console.Write("Ingrese el primer número: ");
            double numero1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingrese el segundo número: ");
            double numero2 = Convert.ToDouble(Console.ReadLine());

            
            double suma = numero1 + numero2;
            double resta = numero1 - numero2;
            double multiplicacion = numero1 * numero2;
            double division = numero1 / numero2;
            int div = (int)(numero1 / numero2); 
            double mod = numero1 % numero2;

            Console.WriteLine($"{numero1} + {numero2} = {suma}");
            Console.WriteLine($"{numero1} - {numero2} = {resta}");
            Console.WriteLine($"{numero1} * {numero2} = {multiplicacion}");
            Console.WriteLine($"{numero1} / {numero2} = {division}");
            Console.WriteLine($"{numero1} div {numero2} = {div}");
            Console.WriteLine($"{numero1} mod {numero2} = {mod}");

            Console.WriteLine("\nEjercicio 2: Jerarquía de operaciones");

            
            Console.Write("Ingrese el valor de a: ");
            double a = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingrese el valor de b: ");
            double b = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingrese el valor de c: ");
            double c = Convert.ToDouble(Console.ReadLine());

            
            double resultado1 = a * b + c;
            double resultado2 = a * (b + c);
            double resultado3 = a / b * c;
            double resultado4 = 3 * a + 2 * b / (c * c);

            
            Console.WriteLine($"a * b + c = {resultado1}");
            Console.WriteLine($"a * (b + c) = {resultado2}");
            Console.WriteLine($"a / b * c = {resultado3}");
            Console.WriteLine($"3a + 2b / c^2 = {resultado4}");

            Console.ReadLine();

            Console.ReadKey();

        }//CIERRE VOID 
    }//CIERRE INTERNAL CLASS 
}//CIERRE NAMESPACE
