﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T4_AJGC1326819_E1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Cálculo de movimiento rectilíneo uniformemente variado");
            Console.WriteLine("Ingrese 3 de las 4 variables (Vf, Vi, a, t)");

            double Vf = 0, Vi = 0, a = 0, t = 0;


            int variablesIngresadas = 0;


            Console.Write("Ingrese la Velocidad Final (Vf, en m/s): ");
            if (double.TryParse(Console.ReadLine(), out Vf))
            {
                variablesIngresadas++;
            }

            Console.Write("Ingrese la Velocidad Inicial (Vi, en m/s): ");
            if (double.TryParse(Console.ReadLine(), out Vi))
            {
                variablesIngresadas++;
            }

            Console.Write("Ingrese la Aceleración (a, en m/s^2): ");
            if (double.TryParse(Console.ReadLine(), out a))
            {
                variablesIngresadas++;
            }

            Console.Write("Ingrese el Tiempo (t, en segundos): ");
            if (double.TryParse(Console.ReadLine(), out t))
            {
                variablesIngresadas++;
            }

            if (variablesIngresadas == 3)
            {

                if (Vf == 0)
                {
                    Vf = Vi + a * t;
                    Console.WriteLine($"La Velocidad Final (Vf) es: {Vf} m/s");
                }
                else if (Vi == 0)
                {
                    Vi = Vf - a * t;
                    Console.WriteLine($"La Velocidad Inicial (Vi) es: {Vi} m/s");
                }
                else if (a == 0)
                {
                    a = (Vf - Vi) / t;
                    Console.WriteLine($"La Aceleración (a) es: {a} m/s^2");
                }
                else if (t == 0)
                {
                    t = (Vf - Vi) / a;
                    Console.WriteLine($"El Tiempo (t) es: {t} segundos");
                }
            }
            else if (variablesIngresadas == 4)
            {
                Console.WriteLine("Error: Se han ingresado las 4 variables. Debe ingresar exactamente 3.");
            }
            else
            {
                Console.WriteLine("Error: Debe ingresar exactamente 3 de las 4 variables.");

                Console.ReadKey();

            }//CIERRE VOID 
        }//CIERRE CLASS
    }
}//CIERRRE NAMESPACE
